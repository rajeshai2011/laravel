<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Post;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $posts=Post::all();

        return response()->json($posts);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator =$request->validate(
            [   
                'title'=>['required'],
                'body'=>['required'],
            ]
        );
      

        $post= Post::create( 
                [   
                    'user_id'=>auth()->user()->id,
                    'title'=>$request->title,
                    'body'=>$request->body,
                ]
        );

        return response()->json($post,201);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
         $post=Post::findOrFail($id);
          return response()->json([
            'status' => true,
            'message' => 'Post found successfully',
            'data' => $post
        ], 200);
         
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validator =  $request->validate([
            'title'=>['required'],
            'body'=>['required'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        $post = Post::findOrFail($id);
        $post->update($request->all());

        return response()->json([
            'status' => true,
            'message' => 'Post updated successfully',
            'data' => $customer
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $post = Post::findOrFail($id);
        $post->delete();
        
        return response()->json([
            'status' => true,
            'message' => 'Post deleted successfully'
        ], 204);
    }
}
