<?php

namespace App\Livewire;

use Livewire\Component;

class SpyInput extends Component
{
   public string $message;
 	
    public function render()
    {
        return view('livewire.spy-input');
    }
}
